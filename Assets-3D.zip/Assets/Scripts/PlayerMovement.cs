using System;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed = 5f;
    private Rigidbody rb;
    private Vector3 spawn;
    public GameObject deathParticles;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        spawn = transform.position;
    }

    void Update()
    {
        Vector3 input = Vector3.zero;

        if (Input.GetKey(KeyCode.W))
        {
            input += transform.forward;
        }
        if (Input.GetKey(KeyCode.S))
        {
            input -= transform.forward;
        }
        if (Input.GetKey(KeyCode.D))
        {
            input += transform.right;
        }
        if (Input.GetKey(KeyCode.A))
        {
            input -= transform.right;
        }

        if (input.magnitude > 1f)
        {
            input.Normalize();
        }

        rb.velocity = input * moveSpeed;

        if (transform.position.y < -2)
        {
            Die();
        }
    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.transform.CompareTag("Enemy"))
        {
            print("I hit enemy");
            Die();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.transform.CompareTag("Goal"))
        {
            GameManager.CompleteLevel();
        }
    }

    void Die()
    {
        Instantiate(deathParticles, transform.position, Quaternion.Euler(270, 0, 0));
        transform.position = spawn;
    }
}
