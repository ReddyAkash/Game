using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class playerlifeTile : MonoBehaviour
{
    private Rigidbody2D rb;
    private Animator anim;
    [SerializeField] public GameObject Cup;
    [SerializeField] public TextMeshProUGUI etext;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        Cup.SetActive(false);

    }
    private IEnumerator OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Trap"))
        {
            Die();
        }
        if (collision.gameObject.CompareTag("Finish"))
        {
            Cup.SetActive(true);
            etext.text = "Hurry won the level";
            yield return new WaitForSeconds(1f);
            etext.text = ".";
            yield return new WaitForSeconds(0.5f);
            etext.text = "..";
            yield return new WaitForSeconds(0.5f);
            etext.text = "...";
            yield return new WaitForSeconds(0.5f);
            etext.text = "Wait for next level";
            StartCoroutine(LoadNextSceneAfterDelay(2f));
        }
    }
    private void Die()
    {
        rb.bodyType = RigidbodyType2D.Static;
        anim.SetTrigger("death");
    }

    private void RestartLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    private IEnumerator LoadNextSceneAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        SceneManager.LoadScene("Level-2 1");
    }
}
