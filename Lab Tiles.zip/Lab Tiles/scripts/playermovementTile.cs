using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playermovementTile : MonoBehaviour
{
    private Rigidbody2D rigid;

    private void Start()
    {
        rigid = GetComponent<Rigidbody2D>();
    }
    private void Update()
    {
        float x = Input.GetAxisRaw("Horizontal");
        float y = Input.GetAxisRaw("Vertical");

        rigid.velocity = new Vector2(x * 5f, y * 5f);
    }
}
